import { logo } from "./logo";
import { like } from "./like";
import { comment } from "./comment";

export { logo, like, comment };
