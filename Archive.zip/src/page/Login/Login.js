import React from "react";

const Login = () => {
  return (
    <div>
      <form action="">
        <input type="text" />
        <input type="password" />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
