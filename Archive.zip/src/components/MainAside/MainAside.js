import React from "react";
import { useSelector } from "react-redux";
import OtherUsers from "../OtherUsers/OtherUsers";
import UserContainer from "../UserContainer/UserContainer";
import Menu from "../Menu/Menu";


const MainAside = () => {
  // всі юзери
  const users = useSelector((state) => state.userReducer.users.data);
  // console.log(users);

  return (
    <>
      <Menu/>
      <UserContainer />
      <OtherUsers title={"Розповіді"} users={users} />
      <OtherUsers title={"Рекомендації"} users={users} recommendation />
    </>
  );
};

export default MainAside;
